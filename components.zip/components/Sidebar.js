import React from 'react'

const Sidebar = () => {
  return (
    <div className='aside'>
        <div className="list">
        <ul>
          <li>
            <a href="#intro">CSS Home</a>
          </li>
          <br/>
          <li>
            <a href="#about">CSS Intro</a>
          </li>
          <br/>
          <li>
            <a href="#work">CSS Syntax</a>
          </li>
          <br/>
          <li>
            <a href="#clients"> Comments</a>
          </li>
        </ul>
      </div>
    </div>
  )
}

export default Sidebar