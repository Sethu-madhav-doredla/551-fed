import React from "react";
import "./myStyles.css";
const Footer = () => {
  return (
    <div>
      <div className="footer">
        <div className="footer-content">
            <h3>My FED Blog</h3>
        </div>
      </div>
    </div>
  );
};

export default Footer;